import React, { useState, useEffect } from 'react';
import { Link } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import {
  Dumbbell,
  Users,
  HeartPulse,
  Clock,
  Check,
  Facebook,
  Twitter,
  Instagram,
  Menu,
  X,
  ArrowLeft,
  ArrowRight,
  PlayCircle
} from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

const IMAGES = {
  hero: "https://images.unsplash.com/photo-1637430308606-86576d8fef3c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1920",
  yoga: "https://images.unsplash.com/photo-1588286840104-8957b019727f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
  crossfit: "https://images.unsplash.com/photo-1620188467120-5042ed1eb5da?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
  boxing: "https://images.unsplash.com/photo-1495555687398-3f50d6e79e1e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
  trainer: "https://images.unsplash.com/photo-1758875569414-120ebc62ada3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080"
};

const navLinks = [
  { name: 'الرئيسية', href: '#home' },
  { name: 'عن الجيم', href: '#about' },
  { name: 'البرامج', href: '#programs' },
  { name: 'الباقات', href: '#pricing' },
];

export default function Home() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div dir="rtl" className="min-h-screen bg-zinc-950 text-zinc-50 font-sans selection:bg-yellow-500 selection:text-zinc-950">
      {/* Navigation */}
      <nav
        className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 border-b border-white/5 ${
          isScrolled ? 'bg-zinc-950/90 backdrop-blur-md py-4' : 'bg-transparent py-6'
        }`}
      >
        <div className="container mx-auto px-6 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-yellow-500 p-2 rounded-lg text-zinc-950">
              <Dumbbell className="w-6 h-6" />
            </div>
            <span className="text-2xl font-bold tracking-tight text-white">
              أيرون<span className="text-yellow-500">فيت</span>
            </span>
          </div>

          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-sm font-medium text-zinc-300 hover:text-yellow-500 transition-colors"
              >
                {link.name}
              </a>
            ))}
            <Link 
              to="/design-system" 
              className="text-sm font-bold text-yellow-500 bg-yellow-500/10 hover:bg-yellow-500/20 px-3 py-1.5 rounded-full transition-colors border border-yellow-500/20"
            >
              نظام التصميم (UI)
            </Link>
          </div>

          <div className="hidden md:flex items-center gap-4">
            <button className="text-sm font-medium hover:text-yellow-500 transition-colors">
              تسجيل الدخول
            </button>
            <button className="bg-yellow-500 hover:bg-yellow-400 text-zinc-950 text-sm font-bold py-2.5 px-6 rounded-full transition-transform hover:scale-105">
              انضم الآن
            </button>
          </div>

          <button
            className="md:hidden text-zinc-300 hover:text-white"
            onClick={() => setMobileMenuOpen(true)}
          >
            <Menu className="w-6 h-6" />
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            className="fixed inset-0 z-50 bg-zinc-950 flex flex-col p-6"
          >
            <div className="flex items-center justify-between mb-12">
              <div className="flex items-center gap-2">
                <div className="bg-yellow-500 p-2 rounded-lg text-zinc-950">
                  <Dumbbell className="w-6 h-6" />
                </div>
                <span className="text-2xl font-bold tracking-tight text-white">
                  أيرون<span className="text-yellow-500">فيت</span>
                </span>
              </div>
              <button
                className="text-zinc-300 hover:text-white bg-white/5 p-2 rounded-full"
                onClick={() => setMobileMenuOpen(false)}
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            
            <div className="flex flex-col gap-6 text-lg font-medium">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className="border-b border-white/10 pb-4 text-zinc-300 hover:text-yellow-500"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {link.name}
                </a>
              ))}
              <Link 
                to="/design-system" 
                className="border-b border-white/10 pb-4 text-yellow-500"
                onClick={() => setMobileMenuOpen(false)}
              >
                نظام التصميم (UI Kit)
              </Link>
            </div>

            <div className="mt-auto flex flex-col gap-4">
              <button className="w-full bg-yellow-500 hover:bg-yellow-400 text-zinc-950 text-lg font-bold py-4 rounded-xl">
                انضم الآن
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero Section */}
      <section id="home" className="relative min-h-screen flex items-center pt-20">
        {/* Background Image */}
        <div className="absolute inset-0 z-0">
          <ImageWithFallback
            src={IMAGES.hero}
            alt="Dark gym with weights"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-zinc-950 via-zinc-950/80 to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-transparent to-transparent"></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-3xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm mb-8"
            >
              <span className="w-2 h-2 rounded-full bg-yellow-500 animate-pulse"></span>
              <span className="text-sm font-medium text-zinc-300">أفضل نادي رياضي لعام 2024</span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-5xl md:text-7xl font-extrabold leading-tight mb-6"
            >
              اكتشف <span className="text-transparent bg-clip-text bg-gradient-to-l from-yellow-400 to-yellow-600">قوتك الحقيقية</span><br />
              وتجاوز كل الحدود
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-lg md:text-xl text-zinc-400 mb-10 max-w-xl leading-relaxed"
            >
              انضم إلى أقوى مجتمع رياضي في المنطقة. احصل على أفضل المعدات والمدربين المحترفين لتحقيق أهدافك وبناء جسم مثالي.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="flex flex-col sm:flex-row items-center gap-4"
            >
              <button className="w-full sm:w-auto bg-yellow-500 hover:bg-yellow-400 text-zinc-950 text-lg font-bold py-4 px-8 rounded-full transition-all flex items-center justify-center gap-2 group">
                ابدأ رحلتك الآن
                <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
              </button>
              <button className="w-full sm:w-auto bg-white/10 hover:bg-white/15 text-white text-lg font-medium py-4 px-8 rounded-full backdrop-blur-sm transition-all flex items-center justify-center gap-2">
                <PlayCircle className="w-5 h-5" />
                شاهد الجيم
              </button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 border-y border-white/5 bg-zinc-900/50">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { number: '+2000', label: 'عضو نشط' },
              { number: '+50', label: 'مدرب محترف' },
              { number: '+30', label: 'برنامج تدريبي' },
              { number: '24/7', label: 'ساعات العمل' }
            ].map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center"
              >
                <div className="text-4xl md:text-5xl font-bold text-white mb-2">{stat.number}</div>
                <div className="text-zinc-400 font-medium">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="about" className="py-24 bg-zinc-950">
        <div className="container mx-auto px-6">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl md:text-5xl font-bold mb-6">لماذا تختار <span className="text-yellow-500">أيرون فيت؟</span></h2>
            <p className="text-zinc-400 text-lg">
              نوفر لك بيئة متكاملة تجمع بين أحدث التقنيات الرياضية والخبرات الاحترافية لتصل إلى هدفك بأسرع وقت.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: <Dumbbell className="w-8 h-8" />,
                title: 'معدات حديثة',
                desc: 'صالتنا مجهزة بأحدث الأجهزة الرياضية من أفضل الماركات العالمية لضمان تجربة تمرين مثالية وآمنة.'
              },
              {
                icon: <Users className="w-8 h-8" />,
                title: 'مدربون معتمدون',
                desc: 'فريق من المدربين المحترفين لمساعدتك في بناء خطة تدريبية مخصصة تناسب قدراتك وأهدافك.'
              },
              {
                icon: <HeartPulse className="w-8 h-8" />,
                title: 'متابعة شاملة',
                desc: 'نقدم لك خططاً غذائية متكاملة ومتابعة دورية لقياس نسبة الدهون والعضلات في جسمك.'
              }
            ].map((feature, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2 }}
                className="bg-zinc-900/50 border border-white/5 p-8 rounded-3xl hover:bg-zinc-900 transition-colors group"
              >
                <div className="bg-yellow-500/10 text-yellow-500 w-16 h-16 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-yellow-500 group-hover:text-zinc-950 transition-colors">
                  {feature.icon}
                </div>
                <h3 className="text-2xl font-bold mb-4 text-white">{feature.title}</h3>
                <p className="text-zinc-400 leading-relaxed">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Classes / Programs */}
      <section id="programs" className="py-24 bg-zinc-900 relative overflow-hidden">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-yellow-500/10 blur-[100px] rounded-full mix-blend-screen pointer-events-none"></div>
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="flex flex-col md:flex-row items-end justify-between mb-16 gap-6">
            <div className="max-w-2xl">
              <h2 className="text-3xl md:text-5xl font-bold mb-6">برامجنا التدريبية</h2>
              <p className="text-zinc-400 text-lg">
                مهما كان هدفك، لدينا البرنامج المناسب لك. انضم إلى فصولنا الجماعية المليئة بالحماس والطاقة.
              </p>
            </div>
            <button className="hidden md:flex items-center gap-2 text-yellow-500 font-bold hover:gap-4 transition-all">
              عرض كل البرامج
              <ArrowLeft className="w-5 h-5" />
            </button>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              { img: IMAGES.crossfit, title: 'الكروس فيت', tags: ['قوة', 'لياقة', 'تحمل'] },
              { img: IMAGES.boxing, title: 'الملاكمة', tags: ['كارديو', 'مرونة', 'دفاع عن النفس'] },
              { img: IMAGES.yoga, title: 'اليوجا', tags: ['استرخاء', 'مرونة', 'توازن'] }
            ].map((program, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="group relative rounded-3xl overflow-hidden aspect-[4/5] cursor-pointer"
              >
                <ImageWithFallback src={program.img} alt={program.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/40 to-transparent opacity-80 group-hover:opacity-90 transition-opacity"></div>
                
                <div className="absolute inset-0 p-8 flex flex-col justify-end">
                  <div className="flex flex-wrap gap-2 mb-4">
                    {program.tags.map(tag => (
                      <span key={tag} className="text-xs font-bold bg-white/20 backdrop-blur-md px-3 py-1 rounded-full text-white">
                        {tag}
                      </span>
                    ))}
                  </div>
                  <h3 className="text-3xl font-bold text-white mb-2 translate-y-4 group-hover:translate-y-0 transition-transform">{program.title}</h3>
                  <div className="flex items-center gap-2 text-yellow-500 font-medium opacity-0 group-hover:opacity-100 transition-opacity translate-y-4 group-hover:translate-y-0 delay-75">
                    <span>انضم للكلاس</span>
                    <ArrowLeft className="w-4 h-4" />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          <button className="w-full mt-10 md:hidden flex items-center justify-center gap-2 text-yellow-500 font-bold border border-yellow-500/30 rounded-xl py-4 bg-yellow-500/5">
            عرض كل البرامج
            <ArrowLeft className="w-5 h-5" />
          </button>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-24 bg-zinc-950">
        <div className="container mx-auto px-6">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl md:text-5xl font-bold mb-6">اختر الباقة المناسبة لك</h2>
            <p className="text-zinc-400 text-lg">
              باقات مرنة تناسب احتياجاتك وميزانيتك، بدون رسوم خفية.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {[
              {
                name: 'الأساسية',
                price: '299',
                period: 'شهرياً',
                features: ['وصول للصالة الرياضية', 'غرفة تبديل الملابس والخزائن', 'تطبيق التمارين الأساسي', 'واي فاي مجاني'],
                isPopular: false
              },
              {
                name: 'المحترفين',
                price: '499',
                period: 'شهرياً',
                features: ['كل ما في الباقة الأساسية', 'الدخول لجميع الفصول الجماعية', 'خطة غذائية مخصصة', 'استشارة شهرية مع مدرب'],
                isPopular: true
              },
              {
                name: 'كبار الشخصيات',
                price: '899',
                period: 'شهرياً',
                features: ['كل ما في باقة المحترفين', 'مدرب شخصي 3 مرات أسبوعياً', 'مساج وجلسات استشفاء', 'دخول صالة الـ VIP'],
                isPopular: false
              }
            ].map((plan, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2 }}
                className={`relative rounded-3xl p-8 ${
                  plan.isPopular 
                    ? 'bg-gradient-to-b from-zinc-800 to-zinc-900 border-2 border-yellow-500 transform md:-translate-y-4' 
                    : 'bg-zinc-900 border border-white/10'
                }`}
              >
                {plan.isPopular && (
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-yellow-500 text-zinc-950 text-sm font-bold px-4 py-1 rounded-full">
                    الأكثر طلباً
                  </div>
                )}
                
                <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
                <div className="mb-6 flex items-baseline gap-2">
                  <span className="text-5xl font-extrabold">{plan.price}</span>
                  <span className="text-zinc-400">ريال / {plan.period}</span>
                </div>
                
                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <div className="bg-yellow-500/20 text-yellow-500 p-1 rounded-full shrink-0 mt-0.5">
                        <Check className="w-3 h-3" />
                      </div>
                      <span className="text-zinc-300">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <button className={`w-full py-4 rounded-xl font-bold transition-all ${
                  plan.isPopular 
                    ? 'bg-yellow-500 hover:bg-yellow-400 text-zinc-950' 
                    : 'bg-white/10 hover:bg-white/20 text-white'
                }`}>
                  اشترك الآن
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0">
          <ImageWithFallback src={IMAGES.trainer} alt="Trainer showing exercises" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-zinc-950/90"></div>
        </div>
        
        <div className="container mx-auto px-6 relative z-10 text-center max-w-3xl">
          <h2 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">جاهز لتغيير حياتك وبناء <span className="text-yellow-500">أفضل نسخة منك؟</span></h2>
          <p className="text-xl text-zinc-300 mb-10">انضم إلينا اليوم واحصل على تقييم مجاني للياقتك البدنية وتجربة ليوم كامل.</p>
          <button className="bg-yellow-500 hover:bg-yellow-400 text-zinc-950 text-xl font-bold py-5 px-10 rounded-full transition-transform hover:scale-105">
            احجز تجربتك المجانية
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-zinc-950 pt-20 pb-10 border-t border-white/10">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
            <div>
              <div className="flex items-center gap-2 mb-6">
                <div className="bg-yellow-500 p-2 rounded-lg text-zinc-950">
                  <Dumbbell className="w-6 h-6" />
                </div>
                <span className="text-2xl font-bold tracking-tight text-white">
                  أيرون<span className="text-yellow-500">فيت</span>
                </span>
              </div>
              <p className="text-zinc-400 leading-relaxed mb-6">
                نحن لسنا مجرد صالة رياضية، نحن مجتمع يسعى دائماً للوصول إلى أعلى مستويات اللياقة البدنية والصحة.
              </p>
              <div className="flex items-center gap-4">
                <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-yellow-500 hover:text-zinc-950 transition-colors text-white">
                  <Facebook className="w-5 h-5" />
                </a>
                <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-yellow-500 hover:text-zinc-950 transition-colors text-white">
                  <Twitter className="w-5 h-5" />
                </a>
                <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-yellow-500 hover:text-zinc-950 transition-colors text-white">
                  <Instagram className="w-5 h-5" />
                </a>
              </div>
            </div>

            <div>
              <h4 className="text-lg font-bold text-white mb-6">روابط سريعة</h4>
              <ul className="space-y-4">
                {['عن الجيم', 'البرامج والكلاسات', 'جدول التمارين', 'المدربون', 'الباقات'].map(link => (
                  <li key={link}>
                    <a href="#" className="text-zinc-400 hover:text-yellow-500 transition-colors flex items-center gap-2">
                      <ArrowLeft className="w-4 h-4 opacity-0 -translate-x-2 transition-all" />
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-bold text-white mb-6">مواعيد العمل</h4>
              <ul className="space-y-4 text-zinc-400">
                <li className="flex justify-between items-center border-b border-white/5 pb-2">
                  <span>السبت - الخميس</span>
                  <span className="text-white font-medium">24 ساعة</span>
                </li>
                <li className="flex justify-between items-center border-b border-white/5 pb-2">
                  <span>الجمعة</span>
                  <span className="text-white font-medium">4 م - 12 ص</span>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-bold text-white mb-6">النشرة البريدية</h4>
              <p className="text-zinc-400 mb-4">اشترك ليصلك أحدث العروض والنصائح الرياضية.</p>
              <form className="flex gap-2">
                <input 
                  type="email" 
                  placeholder="البريد الإلكتروني" 
                  className="bg-white/5 border border-white/10 rounded-xl px-4 py-3 w-full focus:outline-none focus:border-yellow-500 text-white transition-colors"
                />
                <button type="submit" className="bg-yellow-500 hover:bg-yellow-400 text-zinc-950 px-4 py-3 rounded-xl font-bold transition-colors">
                  <ArrowLeft className="w-5 h-5" />
                </button>
              </form>
            </div>
          </div>

          <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-zinc-500 text-sm">
              © 2024 أيرون فيت. جميع الحقوق محفوظة.
            </p>
            <div className="flex gap-6 text-sm text-zinc-500">
              <a href="#" className="hover:text-white transition-colors">سياسة الخصوصية</a>
              <a href="#" className="hover:text-white transition-colors">الشروط والأحكام</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}